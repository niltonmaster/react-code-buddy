import { DevengadoIGV } from '@/components/DevengadoIGV';

export default function DevengadoIGVPage() {
  return <DevengadoIGV />;
}
