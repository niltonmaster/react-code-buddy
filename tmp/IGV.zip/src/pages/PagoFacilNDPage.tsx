import { PantallaPagoFacilND } from "@/components/LiquidacionIGV/PantallaPagoFacilND";

export default function PagoFacilNDPage() {
  return <PantallaPagoFacilND />;
}
