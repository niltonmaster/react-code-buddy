import { LiquidacionIGV } from '@/components/LiquidacionIGV';

const Index = () => {
  return <LiquidacionIGV />;
};

export default Index;
